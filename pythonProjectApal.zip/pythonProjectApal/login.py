def load_logins():
    logins = dict()
    with open('login.txt') as logins_file:
        for line in logins_file:
            line = line.strip()
            # Проверяем, что строка не пустая
            if line:
                # Сначала разбиваем на части по точке с запятой
                login, password = line.split(';')
                # Потом каждую часть разбиваем по двоеточию и берем правую часть
                # (левую не учитываем, считаем что в строке всегда сначала логин, потом пароль)
                login = login.split(':')[1]
                password = password.split(':')[1]
                # Добавляем пару логин-пароль в словарь
                logins[login] = password

    return logins

login = input("login: ")
password = input("password: ")

logins = load_logins()

if login in logins and logins[login] == password:
    print("Вы успешно вошли в систему.")
else:
    print("Неверный логин или пароль.")