from client import Client
from bank_account import Bank_account
from transactions import Transaction


class Bank:
    """Класс для сбора информации о клиентах"""

    def __init__(self, bank_id: int):
        """ """
        self.bank_id = bank_id
        self.clients = []
        self.accounts = []
        self.transactions = []

    def add_client(self, client: Client):
        """добавляем клиента в список """
        self.clients.append(client)

    def add_account(self, account: Bank_account):
        """ добавляем банковские счета в список"""
        self.accounts.append(account)

    def add_transacton(self, transaction: Transaction):
        """ добавляем транзакции в список"""
        self.transactions.append(transaction)

    def __str__(self):
        bank_info = f"Bank ID: {self.bank_id}\n\n"

        bank_info += "Clients:\n"
        for client in self.clients:
            bank_info += f"{client}\n"

        bank_info += "\nBank_account:\n"
        for account in self.accounts:
            bank_info += f"{account}\n"

        return bank_info

    def read_clients(self, clients_fname):
        """ считываем данные о клиентах из файла"""
        with open(clients_fname, 'r', encoding="utf-8") as clients_f:
            for line in clients_f:
                values = line.split(";")
                if line == 7:
                    id_client, surname, name, snils, pass_seria, pass_number, phone = values
                    id_client = int(id_client)
                    pass_number = int(pass_number)
                    client = Client(id_client, surname, name, snils, pass_seria, pass_number, phone)
                    self.clients.append(client)

    def read_account(self, account_fname):
        """считываем данные о банковских аккаунтах из файла"""
        with open(account_fname, 'r', encoding="utf-8") as account_f:
            for line in account_f:
                values = line.split(";")
                if line == 5:
                    id_acc, client_id, accNum, balance, currency = values
                    id_acc = int(id_acc)
                    client_id = int(client_id)
                    balance = float(balance)
                    account = Bank_account(id_acc, client_id, accNum, balance, currency)
                    self.accounts.append(account)

    def read_transaction(self, transaction_fname):
        """считываем данные о транзакциях из файла"""
        with open(transaction_fname, 'r', encoding="utf-8") as transaction_f:
            for line in transaction_f:
                values = line.split(";")
                if line == 6:
                    id_trans, summa, date, time, id_type, id_client = values
                    id_trans = int(id_trans)
                    summa = float(summa)
                    id_client = int(id_client)
                    id_type = int(id_type)
                    transaction = Transaction(id_trans, summa, date, time, id_type, id_client)
                    self.transactions.append(transaction)

    def add_new_client(self, id_client):
        print('Введите Фамилию клиента:')
        surname = input()
        print('Введите Имя клиента:')
        name = input()
        print('Введите СНИЛС клиента')
        snils = input()
        print('Введите серию:')
        pass_seria = int(input())
        print('Номер паспорта:')
        pass_number = int(input())
        print('Введите номер телефона клиента:')
        phone = input()
        client = Client(id_client, surname, name, snils, pass_seria, pass_number, phone)
        bank.add_client(client)
        client_f = open('client.txt', 'a', encoding='utf-8')
        client_f.write(
            f"\n {str(id_client)};{str(surname)};{str(name)};{str(snils)};{str(pass_seria)};{str(pass_number)};{str(phone)}\n")
        client_f.close()
        self.clients.append(Client)
        print('Данные записаны!')
        self.menu()

    def get_all_clients(self):
        for client in self.clients:
            print(client)

        print('вывод клиентов')

    def get_client_info(self):
        id = int(input('Введите id: '))
        # Получение фамилии и имени клиента из файла 'client.txt'
        with open('client.txt', 'r', encoding='utf-8') as file:
            for line in file:
                values = line.split(";")
                if line == 7:
                    id_client, surname, name, snils, pass_seria, pass_number, phone = values
                    id_client = int(id_client)
                    pass_number = int(pass_number)
                if values[0] == id:
                    surname = values[1]
                    name = values[2]
                    break
            else:
                print("Клиент с таким id не найден")
                return

        # Получение номера банковского счета по id клиента из файла 'bank_accounts.txt'
        with open('bank_accounts.txt', 'r', encoding='utf-8') as file:
            for line in file:
                data = line.split(';')
                if data[1] == id:
                    account_number = data[2]
                    break
            else:
                print("Банковский счет с таким id не найден")
                return

        # Вывод полученных данных
        print("Фамилия: ", surname)
        print("Имя: ", name)
        print("Номер банковского счета: ", account_number)

    def get_client_data(self, client_id):
        file = open("transactions.txt", "r", encoding='utf-8')  # Открываем файл для чтения
        client_data = ""  # Переменная для хранения данных клиента

        for line in file:
            data = line.split(";")  # Разделяем строку на элементы по запятой
            if data[0] == client_id:  # Проверяем, совпадает ли id клиента
                client_data = line.strip()  # Удаляем лишние пробелы и сохраняем данные
                break  # Прерываем цикл, так как данные найдены

        file.close()  # Закрываем файл

        return client_data

    def menu(self):
        print('1. Введите 1 для добавления нового клиента\n'
              '2. Введите 2 для вывода клиента и его реквизитов\n'
              '3. Введите 3 для вывода всех клиентов в банке\n'
              '4. Введите 4 для вывода транзакции клиента\n '
              '5. Выход')

        choice = int(input('Выберите пункт: '))

        if choice == 1:
            print('Введите id клиента')
            id_client = int(input())
            self.add_new_client(id_client)

        elif choice == 2:
          self.get_client_info()


        elif choice == 3:
            print('Все клиенты в банке:')
            for client in bank.clients:
                print(client)
            self.menu()

        elif choice == 4:
            client_id = input("Введите id клиента: ")
            client_data = self.get_client_data(client_id)

            if client_data:
                print("Данные клиента:", client_data)
            else:
                print("Клиент с id", client_id, "не найден")

        elif choice == 5:
            exit()

        else:
            print('Ошибка')


if __name__ == '__main__':
    bank = Bank(1)
    bank.read_clients("client.txt")
    bank.read_account("bank_account.txt")
    bank.read_transaction('transactions.txt')
    bank.menu()
