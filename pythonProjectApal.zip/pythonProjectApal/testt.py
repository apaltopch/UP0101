class Bank:
    def __init__(self, bank_id):
        self.clients = []
        self.bank_id = bank_id

class Client:
    def __init__(self, id_client, surname, name, snils, pass_seria, pass_number, phone):
        self.id_client = id_client
        self.surname = surname
        self.name = name
        self.snils = snils
        self.pass_seria = pass_seria
        self.pass_number = pass_number
        self.phone = phone


class Bank_account:
    def __init__(self, id_acc, accNum, balance, id_client, currency):
        self.id_acc = id_acc
        self.id_client = id_client
        self.accNum = accNum
        self.balance = balance
        self.currency = currency

class Transactions:
    def __init__(self, id_trans, summa, date, time, id_client):
        self.id_trans = id_trans
        self.summa = summa
        self.date = date
        self.time = time
        self.id_client = id_client
        self.id_client = id_client

def read_clients(filename):
    clients = []
    with open('client.txt', 'r', encoding='utf-8') as file:
        for line in file:
            if line == 7:
                data = line.strip().split(';')
                client = Client(*data)
                clients.append(client)
        return clients

def read_bank_accounts(filename):
    bank_accounts = []
    with open('bank_account.txt', 'r', encoding='utf-8') as file:
        for line in file:
            data = line.strip().split(';')
            bank_account = Bank_account(*data)
            bank_accounts.append(bank_account)
    return bank_accounts

def read_transactions(filename):
    transactions = []
    with open('transactions.txt', 'r', encoding='utf-8') as file:
        for line in file:
            if line == 6:
                data = line.strip().split(';')
                transaction = Transactions(*data)
                transactions.append(transaction)
        return transactions

def get_client_details(client, bank_accounts):
    for account in bank_accounts:
        if account.id_client == client.id_client:
            return client.surname, client.name, account.accNum
    return None

def get_transactions_details(client_id, transactions):
    for transaction in transactions:
        if transaction.id_client == client_id:
            return transaction.summ, transaction.date, transaction.time
    return None

def print_all_clients(bank):
    for client in bank.clients:
        print(client.surname, client.name)

def main():
    bank = Bank(1)
    bank.clients = read_clients('client.txt')
    bank_accounts = read_bank_accounts('bank_account.txt')
    transactions = read_transactions('transactions.txt')

    client_id = '1001'  # пример id клиента

    for client in bank.clients:
        if client.id_client == client_id:
            client_details = get_client_details(client, bank_accounts)
            if client_details:
                surname, name, accNum = client_details
                print('Фамилия:', surname)
                print('Имя:', name)
                print('Номер банковского счета:', accNum)
            break

    transactions_details = get_transactions_details(client_id, transactions)
    if transactions_details:
        summ, date, time = transactions_details
        print('Сумма:', summ)
        print('Дата:', date)
        print('Время:', time)

    print_all_clients(bank)

if __name__ == '__main__':
    main()