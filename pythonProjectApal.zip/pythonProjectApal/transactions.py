class Transaction:
    """
    ...
    Атрибуты
    --------
    ID транзакции;
    Сумма транзакци;
    Дата транзакции;
    Время транзакции;
    ID Тип транзакции;
    ID клиента
    """
    def __init__(self, id_trans: int, summa: float, date: str, time: str, id_type: int, id_client: int):
        self.id_trans = id_trans
        self.summa = summa
        self.date = date
        self.time = time
        self.id_type = id_type
        self.id_client = id_client


    def __str__(self):
        return f"{self.id_trans}. {self.summa} {self.date} {self.time} {self.id_type} {self.id_client} "