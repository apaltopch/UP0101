class Client:
    def __init__(self, id_client, surname, name, snils, pass_seria, pass_number, phone):
        self.id_client = id_client
        self.surname = surname
        self.name = name
        self.snils = snils
        self.pass_seria = pass_seria
        self.pass_number = pass_number
        self.phone = phone

    def __str__(self):
        return f"ID: {self.id_client}, Фамилия: {self.surname}, Имя: {self.name}, СНИЛС: {self.snils}, Паспорт: {self.pass_seria} {self.pass_number}, Телефон: {self.phone}"

class Bank_account:
    def __init__(self, id_acc, client_id, accNum, balance, currency):
        self.id_acc = id_acc
        self.client_id = client_id
        self.accNum = accNum
        self.balance = balance
        self.currency = currency

    def __str__(self):
        return f"ID счета: {self.id_acc}, ID клиента: {self.client_id}, Номер счета: {self.accNum}, Баланс: {self.balance} {self.currency}"

class Transactions:
    def __init__(self, id_trans, summa, date, time, id_type, id_client):
        self.id_trans = id_trans
        self.summa = summa
        self.date = date
        self.time = time
        self.id_type = id_type
        self.id_client = id_client

    def __str__(self):
        return f"ID транзакции: {self.id_trans}, Сумма: {self.summa}, Дата: {self.date}, Время: {self.time}, ID типа: {self.id_type}, ID клиента: {self.id_client}"

clients = []
accounts = []
transactions = []

with open('client.txt', 'r', encoding='utf-8') as client_file:
    for line in client_file:
        data = line.split(';')
        if line == 7:
            client = Client(data[0], data[1], data[2], data[3], data[4], data[5], data[6])
            clients.append(client)

with open('bank_account.txt', 'r', encoding='utf-8') as account_file:
    for line in account_file:
        data = line.split(';')
        if line == 5:
            account = Bank_account(data[0], data[1], data[2], data[3], data[4])
            accounts.append(account)

with open('transactions.txt', 'r', encoding='utf-8') as transaction_file:
    for line in transaction_file:
        data = line.split(';')
        if line == 6:
            transaction = Transactions(data[0], data[1], data[2], data[3], data[4], data[5])
            transactions.append(transaction)

def add_new_client():
    id_client = input("Введите ID клиента: ")
    surname = input("Введите фамилию клиента: ")
    name = input("Введите имя клиента: ")
    snils = input("Введите СНИЛС клиента: ")
    pass_seria = input("Введите серию паспорта клиента: ")
    pass_number = input("Введите номер паспорта клиента: ")
    phone = input("Введите телефон клиента: ")

    new_client = Client(id_client, surname, name, snils, pass_seria, pass_number, phone)
    clients.append(new_client)

    with open('client.txt', 'a') as client_file:
        client_file.write(f"{id_client},{surname},{name},{snils},{pass_seria},{pass_number},{phone}")

def get_client_info(id_client):
    with open('bank_account.txt', 'r') as file:
        for line in file:
            data = line.split(',')
            if line == 5:
                if data[1] == id_client:
                    with open('client.txt', 'r') as client_file:
                        for client_line in client_file:
                            client_data = client_line.split(',')
                            if client_data[0] == id_client:
                                return f"Фамилия: client_data[1], Имя: client_data[2], Номер счета: data[2]"
                        return "Клиент не найден"

def get_all_clients():
    all_clients = []
    for client in clients:
        all_clients += str(client) + ""
    return all_clients

while True:
    print("1. Добавить нового клиента")
    print("2. Получить информацию о клиенте")
    print("3. Вывести всех клиентов")
    print("4. Выход")
    choice = int(input("Выберите действие: "))

    if choice == 1:
        add_new_client()
    elif choice == 2:
        id_client = input("Введите ID клиента: ")
        print(get_client_info(id_client))
    elif choice == 3:
        print(get_all_clients())
    elif choice == 4:
        break
    else:
        print("Неверный выбор")
