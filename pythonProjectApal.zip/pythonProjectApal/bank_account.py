'''
ID счета;
ID клиента;
номер счета;
баланс счета;
валюта счета;
'''

class Bank_account:
    def __init__(self, id_acc: int, client_id: int, accNum: str, balance: float, currency: str):
        self.id_acc = id_acc
        self.client_id = client_id
        self.accNum = accNum
        self.balance = balance
        self.currency = currency

    def __str__(self):
        return f"{self.id_acc}. {self.client_id} {self.accNum} {self.balance} {self.currency}"