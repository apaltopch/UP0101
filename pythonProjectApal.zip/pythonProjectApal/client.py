'''
ID клиента
Фамилия Имя;
СНИЛС;
Серия паспорта;
Номер паспорта;
Телефон;
'''

class Client:
    def __init__(self, id_client: int, surname: str, name: str, snils: str, pass_seria: str, pass_number: int, phone: str):
        self.id_client = id_client
        self.surname = surname
        self.name = name
        self.snils = snils
        self.pass_seria = pass_seria
        self.pass_number = pass_number
        self.phone = phone

    def __str__(self):
        return f"{self.id_client}. {self.surname} {self.name} {self.snils} {self.pass_seria} {self.pass_number} {self.phone}"