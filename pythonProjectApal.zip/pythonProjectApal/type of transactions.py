class Type:
    """
        ...
        Атрибуты
        --------
        ID;
        Тип транзакции;
        """
    def __init__(self, id_type: int, type: str):
        self.id_type = id_type
        self.type = type


    def __str__(self):
        return f"{self.id_type}. {self.type} "