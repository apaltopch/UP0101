class Activity:
    """
  ...
    Атрибуты
    --------
    ID активности;
    Дата активности;
    время активности;
    Дата последнего доступа;
    Время последнего доступа;
    ID клиента
    """

    def __init__(self, id_actvity: int, date_act: str, time_act: str, date_last: str, time_last: str,id_client: int):
        self.id_activity = id_actvity
        self.date_act = date_act
        self.time_act = time_act
        self.date_last = date_last
        self.time_last = time_last
        self.id_client = id_client


    def __str__(self):
        return f"{self.id_activity}. {self.date_act} {self.time_act} {self.date_last} {self.time_last} {self.id_client} "

